https://github.com/gunther520/COMP5412


Only three wav file, as stated in the final report.

1. noisy.wav: The original noisy speech audio with guitar background noise.
2. denoised_model_2.wav: The denoised audio using Proposed Model 2, raw waveform is model_2.png
3. denoised_model_3.wav: The denoised audio using Proposed Model 3, raw waveform is model_3.png